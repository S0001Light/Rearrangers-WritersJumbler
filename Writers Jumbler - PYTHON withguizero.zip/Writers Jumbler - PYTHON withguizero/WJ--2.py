from guizero import App, Window, MenuBar, TextBox, Text, PushButton, Slider
import random
from operator import itemgetter
import os
from os import path
import io
import sys

def file_function():
    ("File option")
def edit_function():
    ("Edit Option")
def open_window_0():
    window0.show()
def close_window_0():
    window0.hide()
def open_window_1():
    window1.show()
def close_window_1():
    window1.hide()
def open_window_2():
    window2.show()
def close_window_2():
    window2.hide()

def open_window_4():
    window4.show()
def close_window_4():
    window4.hide()
def open_window_5():
    window5.show()
def close_window_5():
    window5.hide()
def open_window_6():
    window6.show()
def close_window_6():
    window6.hide()

app = App(title="Writers Jumbler - 2 Columns", bg="#d2d2d2", width=614, height=350, layout="grid")

window5 = Window(app, title="WJ-Color Background", bg="#d2d2d2", width=400, height=340)
message2 = Text(window5, text="", size=12)

mna = ""
def Change1(mna):
    haaha = (Change1)

mnb = ""
def Change2(mnb):
    haahb = (Change2)

mnc = ""
def Change3(mnc):
    haahc = (Change3)
    
lbl0 = Text(window5, text="", size=2)
message7 = Text(window5, text="RED", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide1 = Slider(window5, command=Change1, start=0, end=255)
colorSlide1.bg = "#ffffff"
colorSlide1.width = "255"
colorSlide1.value = "255"
lbl0 = Text(window5, text="", size=2)
message8 = Text(window5, text="GREEN", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide2 = Slider(window5, command=Change2, start=0, end=255)
colorSlide2.bg = "#ffffff"
colorSlide2.width = "255"
colorSlide2.value = "255"
lbl0 = Text(window5, text="", size=2)
message9 = Text(window5, text="BLUE", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide3 = Slider(window5, command=Change3, start=0, end=255)
colorSlide3.bg = "#ffffff"
colorSlide3.width = "255"
colorSlide3.value = "255"

def colorRGB():
    colorRa = colorSlide1.value
    colorGa = colorSlide2.value
    colorBa = colorSlide3.value
    colorCT = (colorRa, colorGa, colorBa)
    window0.bg = colorCT

lbl0 = Text(window5, text="", size=2)
color_text = PushButton(window5, command=colorRGB, text="Color This Window Background")
color_text.bg = "#c0c0ff"
color_text.text_color = "#000000"

close_window_5()

window6 = Window(app, title="WJ-Color Font", bg="#d2d2d2", width=400, height=340)

message2 = Text(window6, text="", size=12)

mna = ""
def Change4(mna):
    haaha = (Change4)

mnb = ""
def Change5(mnb):
    haahb = (Change5)

mnc = ""
def Change6(mnc):
    haahc = (Change6)

lbl0 = Text(window6, text="", size=2)
message10 = Text(window6, text="RED", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide4 = Slider(window6, command=Change4, start=0, end=255)
colorSlide4.bg = "#ffffff"
colorSlide4.width = "255"
colorSlide4.value = "0"
lbl0 = Text(window6, text="", size=2)
message11 = Text(window6, text="GREEN", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide5 = Slider(window6, command=Change5, start=0, end=255)
colorSlide5.bg = "#ffffff"
colorSlide5.width = "255"
colorSlide5.value = "0"
lbl0 = Text(window6, text="", size=2)
message12 = Text(window6, text="BLUE", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide6 = Slider(window6, command=Change6, start=0, end=255)
colorSlide6.bg = "#ffffff"
colorSlide6.width = "255"
colorSlide6.value = "0"

def colorCFT():
    colorRf2 = colorSlide4.value
    colorGf2 = colorSlide5.value
    colorBf2 = colorSlide6.value
    colorCTf = (colorRf2, colorGf2, colorBf2)
    window0.text_color = colorCTf

message2 = Text(window6, text="", size=8)
color_text = PushButton(window6, command=colorCFT, text="Color Fonts")
color_text.bg = "#c0c0ff"
color_text.text_color = "#000000"
close_window_6()

def savas2():

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value
    kValue = text11.value
    lValue = text12.value
    mValue = text13.value
    nValue = text14.value
    oValue = text15.value
    pValue = text16.value
    qValue = text17.value
    rValue = text18.value
    sValue = text19.value
    tValue = text20.value

    word = "WJ2_inOrder_2c_"
    i = random.randint(0, 1000000)
    z = word + str(i) + ".csv"

    file = open(z, "w")

    allMessages = str(aValue) +  "," +  str(bValue) +  "," +  str(cValue) +  "," +  str(dValue) +  "," +  str(eValue) +  "," +  str(fValue) +  "," +  str(gValue) +  "," +  str(hValue) +  "," +  str(iValue) +  "," +  str(jValue) +  "," +  str(kValue) +  "," +  str(lValue) +  "," + str(mValue) +  "," +  str(nValue) +  "," +  str(oValue) +  "," +  str(pValue) +  "," +  str(qValue) +  "," +  str(rValue) +  "," +  str(sValue) +  "," +  str(tValue)
    file.write(allMessages)
    file.close()

def getfiles7():
    list_a = []
    list_b = []
    list_c = []
    list_d = []
    list_e = []
    list_f = []
    list_g = []
    list_h = []
    list_i = []
    list_j = []
    list_k = []
    list_l = []
    list_m = []
    list_n = []
    list_o = []
    list_p = []
    list_q = []
    list_r = []
    list_s = []
    list_t = []
    ab = text1d1.value
    with open(ab, "r") as t:
        for line in t:
            words = line.split(",")
            word_1 = words[0]
            word_2 = words[1]
            word_3 = words[2]
            word_4 = words[3]
            word_5 = words[4]
            word_6 = words[5]
            word_7 = words[6]
            word_8 = words[7]
            word_9 = words[8]
            word_10 = words[9]
            word_11 = words[10]
            word_12 = words[11]
            word_13 = words[12]
            word_14 = words[13]
            word_15 = words[14]
            word_16 = words[15]
            word_17 = words[16]
            word_18 = words[17]
            word_19 = words[18]
            word_20 = words[19]
            text1.value = word_1
            text2.value = word_2
            text3.value = word_3
            text4.value = word_4
            text5.value = word_5
            text6.value = word_6
            text7.value = word_7
            text8.value = word_8
            text9.value = word_9
            text10.value = word_10
            text11.value = word_11
            text12.value = word_12
            text13.value = word_13
            text14.value = word_14
            text15.value = word_15
            text16.value = word_16
            text17.value = word_17
            text18.value = word_18
            text19.value = word_19
            text20.value = word_20

def getfiles5():
    files = []
    files = os.listdir(os.getcwd())
    files = "".join(repr(files).replace(",", "\n")).replace("[", "").replace("]", "").replace("'", "")
    message4.value = files

exitWindow = exit

file_Menu = MenuBar(app, toplevel=["File", "Options"], options=[ [ ["Save, with Random File Name", savas2], ["Open Directory Box", open_window_2], ["Open Directory Window", open_window_1], ["List Files In WJ-Directory", getfiles5], ["Fill, From File", getfiles7], ["Exit, Writers Jumbler", exitWindow] ], [ ["Open Rearrangements", open_window_0], ["Open Color Background", open_window_5], ["Open Color Font", open_window_6], ["Open Action Buttons", open_window_4]],])
message = Text(app, text="", size=20, grid=[0,1])
text1 = TextBox(app, width=50, height=16, grid=[0,2])
text1.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,3])
text2 = TextBox(app, width=50, height=16, grid=[0,4])
text2.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,5])
text3 = TextBox(app, width=50, height=16, grid=[0,6])
text3.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,7])
text4 = TextBox(app, width=50, height=16, grid=[0,8])
text4.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,9])
text5 = TextBox(app, width=50, height=16, grid=[0,10])
text5.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,11])
text6 = TextBox(app, width=50, height=16, grid=[0,12])
text6.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,13])
text7 = TextBox(app, width=50, height=16, grid=[0,14])
text7.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,15])
text8 = TextBox(app, width=50, height=16, grid=[0,16])
text8.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,17])
text9 = TextBox(app, width=50, height=16, grid=[0,18])
text9.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,19])
text10 = TextBox(app, width=50, height=16, grid=[0,20])
text10.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,21])

text11 = TextBox(app, width=50, height=16, grid=[1,2])
text11.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,3])
text12 = TextBox(app, width=50, height=16, grid=[1,4])
text12.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,5])
text13 = TextBox(app, width=50, height=16, grid=[1,6])
text13.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,7])
text14 = TextBox(app, width=50, height=16, grid=[1,8])
text14.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,9])
text15 = TextBox(app, width=50, height=16, grid=[1,10])
text15.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,11])
text16 = TextBox(app, width=50, height=16, grid=[1,12])
text16.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,13])
text17 = TextBox(app, width=50, height=16, grid=[1,14])
text17.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,15])
text18 = TextBox(app, width=50, height=16, grid=[1,16])
text18.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,17])
text19 = TextBox(app, width=50, height=16, grid=[1,18])
text19.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,19])
text20 = TextBox(app, width=50, height=16, grid=[1,20])
text20.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,21])

def messages():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message1.value = xxxxx0
    
def messagesC2():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text11.value
    bValue = text12.value
    cValue = text13.value
    dValue = text14.value
    eValue = text15.value
    fValue = text16.value
    gValue = text17.value
    hValue = text18.value
    iValue = text19.value
    jValue = text20.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message2C.value = xxxxx0
    
def messagesCa():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx1 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz1 = zzx1

    qa = zzx1[0]
    qb = zzx1[1]
    qc = zzx1[2]
    qd = zzx1[3]
    qe = zzx1[4]
    qf = zzx1[5]
    qg = zzx1[6]
    qh = zzx1[7]
    qi = zzx1[8]
    qj = zzx1[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message1.value = xxxxx0

    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    kValue = text11.value
    lValue = text12.value
    mValue = text13.value
    nValue = text14.value
    oValue = text15.value
    pValue = text16.value
    qValue = text17.value
    rValue = text18.value
    sValue = text19.value
    tValue = text20.value

    zk = []
    zl = []
    zm = []
    zn = []
    zo = []
    zp = []
    zq = []
    zr = []
    zs = []
    zt = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    zk = [value1, kValue, '\n']
    zl = [value2, lValue, '\n']
    zm = [value3, mValue, '\n']
    zn = [value4, nValue, '\n']
    zo = [value5, oValue, '\n']
    zp = [value6, pValue, '\n']
    zq = [value7, qValue, '\n']
    zr = [value8, rValue, '\n']
    zs = [value9, sValue, '\n']
    zt = [value10, tValue, '\n']
    ya = [zk, zl, zm, zn, zo, zp, zq, zr, zs, zt]

    zzx2 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz2 = zzx2

    qk = zzx2[0]
    ql = zzx2[1]
    qm = zzx2[2]
    qn = zzx2[3]
    qo = zzx2[4]
    qp = zzx2[5]
    qq = zzx2[6]
    qr = zzx2[7]
    qs = zzx2[8]
    qt = zzx2[9]

    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]
    xp = qp[-2]
    xq = qq[-2]
    xr = qr[-2]
    xs = qs[-2]
    xt = qt[-2]

    kk = [xk]
    kl = [xl]
    km = [xm]
    kn = [xn]
    ko = [xo]
    kp = [xp]
    kq = [xq]
    kr = [xr]
    ks = [xs]
    kt = [xt]

    xxxx = (kk, kl, km, kn, ko, kp, kq, kr, ks, kt)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message2C.value = xxxxx0
    
    word = "WJ2_Jumble_Save_2c_"
    i = random.randint(0, 1000000)
    z = word + str(i) + ".csv"

    file = open(z, "w")

    allMessages = str(ka) +  "," +  str(kb) +  "," +  str(kc) +  "," +  str(kd) +  "," +  str(ke) +  "," +  str(kf) +  "," +  str(kg) +  "," +  str(kh) +  "," +  str(ki) +  "," +  str(kj) + "," +  str(kk) +  "," +  str(kl) +  "," +  str(km) +  "," +  str(kn) +  "," +  str(ko) +  "," +  str(kp) +  "," +  str(kq) +  "," +  str(kr) +  "," +  str(ks) +  "," +  str(kt)
    file.write(allMessages)
    file.close()

window0 = Window(app, title="WJ-List of Rearrangement", bg="#d2d2d2", width=614, height=400, layout="grid")
message2 = Text(window0, text="", size=8, grid=[0,0])
message1 = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[0,1])
message2 = Text(window0, text="", size=8, grid=[1,0])
message2C = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[1,1])
close_window_0()

window1 = Window(app, title="WJ-Directory", bg="#d2d2d2", width=270, height=470, layout="auto")
message2 = Text(window1, text="Current Directory", size=10, font="monospace", color="#000000")
message2 = Text(window1, text="CTRL-C to Copy, CTRL-V to Paste", size=10, font="monospace", color="#000000")
message4 = TextBox(window1, text="", height=960, width=350, multiline=True, scrollbar=True)
message4.bg = "#ffffff"
message4.text_color = "#000000"
close_window_1()

window2 = Window(app, title="WJ-From This Directory", bg="#d2d2d2", width=400, height=80)
message2 = Text(window2, text=" ", size=2)
message2 = Text(window2, text="Working Data File:", size=10)
message2 = Text(window2, text="Include extension", size=8)
text1d1 = TextBox(window2, "WJ_Data_File_Name_Here" + ".csv", width=50, height=16)
text1d1.bg = "#ffffff"
text1d1.text_color = "#000000"
close_window_2()

window4 = Window(app, title="WJ-Action Buttons", bg="#d2d2d2", width=200, height=390)
message2 = Text(window4, text=" ", size=8)
save_text = PushButton(window4, command=savas2, text="Save All Rows In Order Written")
save_text.bg = "#c0c0ff"
save_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
updateA_text = PushButton(window4, command=messagesCa, text="Rearrange All Columns & Save Jumble")
updateA_text.bg = "#c0c0ff"
updateA_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update_text = PushButton(window4, command=messages, text="Rearrange Column 1")
update_text.bg = "#c0c0ff"
update_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update2_text = PushButton(window4, command=messagesC2, text="Rearrange Column 2")
update2_text.bg = "#c0c0ff"
update2_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
fill_text = PushButton(window4, command=getfiles7, text="Fill From Filename Typed In Directory Box")
fill_text.bg = "#c0c0ff"
fill_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
getThose_files = PushButton(window4, command=getfiles5, text="List Files Of Current Directory")
getThose_files.bg = "#c0c0ff"
getThose_files.text_color = "#000000"
close_window_4()

app.display()
