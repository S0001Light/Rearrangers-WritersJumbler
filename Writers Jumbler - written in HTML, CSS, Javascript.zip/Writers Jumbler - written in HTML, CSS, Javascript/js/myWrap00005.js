function myRap00001() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);

var linewrp1 = document.getElementById("az1").value;
var linewrp2 = document.getElementById("bz1").value;
var linewrp3 = document.getElementById("cz1").value;
var linewrp4 = document.getElementById("dz1").value;
var linewrp5 = document.getElementById("ez1").value;
var linewrp6 = document.getElementById("fz1").value;
var linewrp7 = document.getElementById("gz1").value;
var linewrp8 = document.getElementById("hz1").value;
var linewrp9 = document.getElementById("iz1").value;
var linewrp10 = document.getElementById("jz1").value;

var rap1 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand1 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp1 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap2 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand2 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp2 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap3 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand3 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp3 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap4 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand4 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp4 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap5 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand5 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp5 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap6 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand6 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp6 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap7 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand7 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp7 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap8 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand8 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp8 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap9 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand9 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp9 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap10 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand10 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp10 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00001 = [rap1, rap2, rap3, rap4, rap5, rap6, rap7, rap8, rap9, rap10];
    document.getElementById("Rap00001").innerHTML = getRap00001.sort();
}

function myRap00002() {

var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);

var linewrp11 = document.getElementById("kz1").value;
var linewrp12 = document.getElementById("lz1").value;
var linewrp13 = document.getElementById("mz1").value;
var linewrp14 = document.getElementById("nz1").value;
var linewrp15 = document.getElementById("oz1").value;
var linewrp16 = document.getElementById("pz1").value;
var linewrp17 = document.getElementById("qz1").value;
var linewrp18 = document.getElementById("rz1").value;
var linewrp19 = document.getElementById("sz1").value;
var linewrp20 = document.getElementById("tz1").value;

var rap11 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand11 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp11 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap12 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand12 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp12 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap13 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand13 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp13 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap14 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand14 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp14 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap15 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand15 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp15 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap16 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand16 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp16 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap17 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand17 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp17 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap18 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand18 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp18 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap19 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand19 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp19 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap20 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand20 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp20 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00002 = [rap11, rap12, rap13, rap14, rap15, rap16, rap17, rap18, rap19, rap20];
    document.getElementById("Rap00002").innerHTML = getRap00002.sort();
}

function myRap00003() {

var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);

var linewrp21 = document.getElementById("uz1").value;
var linewrp22 = document.getElementById("vz1").value;
var linewrp23 = document.getElementById("wz1").value;
var linewrp24 = document.getElementById("xz1").value;
var linewrp25 = document.getElementById("yz1").value;
var linewrp26 = document.getElementById("zz1").value;
var linewrp27 = document.getElementById("aaz1").value;
var linewrp28 = document.getElementById("abz1").value;
var linewrp29 = document.getElementById("acz1").value;
var linewrp30 = document.getElementById("adz1").value;

var rap21 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand21 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp21 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap22 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand22 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp22 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap23 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand23 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp23 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap24 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand24 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp24 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap25 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand25 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp25 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap26 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand26 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp26 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap27 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand27 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp27 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap28 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand28 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp28 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap29 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand29 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp29 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap30 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand30 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp30 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00003 = [rap21, rap22, rap23, rap24, rap25, rap26, rap27, rap28, rap29, rap30];
    document.getElementById("Rap00003").innerHTML = getRap00003.sort();
}

function myRap00004() {

var numRand41 = Math.floor((Math.random() * 10) + 1);
var numRand42 = Math.floor((Math.random() * 10) + 1);
var numRand43 = Math.floor((Math.random() * 10) + 1);
var numRand44 = Math.floor((Math.random() * 10) + 1);
var numRand45 = Math.floor((Math.random() * 10) + 1);
var numRand46 = Math.floor((Math.random() * 10) + 1);
var numRand47 = Math.floor((Math.random() * 10) + 1);
var numRand48 = Math.floor((Math.random() * 10) + 1);
var numRand49 = Math.floor((Math.random() * 10) + 1);
var numRand50 = Math.floor((Math.random() * 10) + 1);

var linewrp41 = document.getElementById("aez1").value;
var linewrp42 = document.getElementById("afz1").value;
var linewrp43 = document.getElementById("agz1").value;
var linewrp44 = document.getElementById("ahz1").value;
var linewrp45 = document.getElementById("aiz1").value;
var linewrp46 = document.getElementById("ajz1").value;
var linewrp47 = document.getElementById("akz1").value;
var linewrp48 = document.getElementById("alz1").value;
var linewrp49 = document.getElementById("amz1").value;
var linewrp50 = document.getElementById("anz1").value;

var rap41 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand41 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp41 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap42 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand42 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp42 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap43 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand43 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp43 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap44 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand44 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp44 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap45 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand45 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp45 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap46 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand46 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp46 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap47 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand47 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp47 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap48 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand48 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp48 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap49 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand49 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp49 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap50 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand50 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp50 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00004 = [rap41, rap42, rap43, rap44, rap45, rap46, rap47, rap48, rap49, rap50];
    document.getElementById("Rap00004").innerHTML = getRap00004.sort();
}

function myRap00005() {

var numRand51 = Math.floor((Math.random() * 10) + 1);
var numRand52 = Math.floor((Math.random() * 10) + 1);
var numRand53 = Math.floor((Math.random() * 10) + 1);
var numRand54 = Math.floor((Math.random() * 10) + 1);
var numRand55 = Math.floor((Math.random() * 10) + 1);
var numRand56 = Math.floor((Math.random() * 10) + 1);
var numRand57 = Math.floor((Math.random() * 10) + 1);
var numRand58 = Math.floor((Math.random() * 10) + 1);
var numRand59 = Math.floor((Math.random() * 10) + 1);
var numRand60 = Math.floor((Math.random() * 10) + 1);

var linewrp51 = document.getElementById("aoz1").value;
var linewrp52 = document.getElementById("apz1").value;
var linewrp53 = document.getElementById("aqz1").value;
var linewrp54 = document.getElementById("arz1").value;
var linewrp55 = document.getElementById("asz1").value;
var linewrp56 = document.getElementById("atz1").value;
var linewrp57 = document.getElementById("auz1").value;
var linewrp58 = document.getElementById("avz1").value;
var linewrp59 = document.getElementById("awz1").value;
var linewrp60 = document.getElementById("axz1").value;

var rap51 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand51 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp51 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap52 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand52 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp52 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap53 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand53 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp53 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap54 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand54 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp54 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap55 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand55 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp55 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap56 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand56 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp56 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap57 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand57 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp57 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap58 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand58 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp58 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap59 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand59 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp59 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap60 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand60 + '</p>' + '<p style="padding-left:10px; font-size:12px; font-family:monospace;">' + linewrp60 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap00005 = [rap51, rap52, rap53, rap54, rap55, rap56, rap57, rap58, rap59, rap60];
    document.getElementById("Rap00005").innerHTML = getRap00005.sort();
}